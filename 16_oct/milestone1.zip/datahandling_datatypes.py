import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
df=pd.read_csv(r'C:\Users\Trainer\Downloads\urban_mobility.csv')
print(df.head(5))
# A2. Create a new column Energy_Per_Km = Energy_Used_kWh / Distance_Km.
df['Energy_Per_Km']=df['Energy_Used_kWh']/df['Distance_Km']
# A3. Display only Electric Van records where Maintenance_Flag is Yes.
print(df[(df['Maintenance_Flag']=='Yes')&(df['Vehicle_Type']=='Electric Van')])
# A4. Group by Vehicle_Type and display average Distance_Km and total Trips_Count.
df.groupby('Vehicle_Type').agg({'Distance_Km':'mean','Trips_Count':'sum'})
# A5. Use NumPy to calculate the mean, maximum and minimum of Energy_Used_kWh.
mean_val=np.mean(df['Energy_Used_kWh'])
max_val=np.max(df['Energy_Used_kWh'])
min_val=np.min(df['Energy_Used_kWh'])
# A6. Create one bar chart showing average Energy_Used_kWh by Vehicle_Type using Matplotlib or Seaborn.
df.groupby('Vehicle_Type')['Energy_Used_kWh'].mean().plot(kind='bar')

# A7. Load equipment_events.json and print event_id, asset type, site and severity for every event.
import json
with open(r'C:\Users\Trainer\Downloads\equipment_events.json') as f:
    data = json.load(f)
for e in data:
    print(e.get('event_id'),e.get('asset').get('type'),e.get('asset').get('site'),e.get('severity'))
# A8. Display JSON records with temperature above 70. If actions is missing, display 'No actions recorded'.
for e in data:
    if e.get('temperature',0)>70:
        print(e,e.get('actions','No actions recorded'))
# A9. Read coastal_monitoring_log.txt and count total words and the number of times the word 'inspection'
# appears.
text=open('coastal_monitoring.txt','r').read()
total_words=len(text.split())
inspection_count=text.lower().count('inspection')

# A10. Print only the lines containing either 'boardwalk', 'maintenance', or 'wind'
keywords=['boardwalk','maintenance','wind']
for line in open(r'C:\Users\Trainer\Downloads\equipment_events.txt'):
    if any(kw in line.lower() for kw in keywords):
        print(line.strip())

