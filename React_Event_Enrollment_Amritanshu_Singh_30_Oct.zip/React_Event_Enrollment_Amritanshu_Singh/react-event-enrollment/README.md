# Event Enrollment Manager

Front-end web application built with React, Vite, and React Router for a local community learning center. It handles workshop browsing, seat registration, dynamic capacity updates, and cancellations. Data is persisted in the browser via `localStorage` without any backend API.

---

## Quick Start & Setup

### Prerequisites
* Node.js (v18+)
* npm

### Running the App Locally

1. Go to the project root directory:
   ```bash
   cd react-event-enrollment
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Launch the development server:
   ```bash
   npm run dev
   ```
   Open the localhost link shown in the terminal (defaults to `http://localhost:5173`).

4. Optional production build test:
   ```bash
   npm run build
   npm run preview
   ```

---

## Tech Stack

* **React 18** (functional components, standard hooks: `useState`, `useEffect`, `useMemo`, `useContext`)
* **Vite** (build tool and dev server)
* **React Router v6** (client-side routing between `/` and `/registrations`)
* **Plain CSS** (responsive grid, modal backdrop, mobile-friendly table layout)
* **Web Storage API** (`localStorage` for persistence)

---

## File & Folder Overview

```text
react-event-enrollment/
├── index.html
├── package.json
├── vite.config.js
├── README.md
└── src/
    ├── main.jsx                     
    ├── App.jsx                     
    ├── index.css                 
    ├── data/
    │   └── events.js             
    ├── context/
    │   └── RegistrationContext.jsx  # Shared state, seat math, and localStorage sync
    ├── components/
    │   ├── Navbar.jsx               # Navigation bar with dynamic registration counter
    │   ├── EventCard.jsx            # Event card with status badges & action button
    │   └── RegistrationModal.jsx    # Registration modal and input validation
    └── pages/
        ├── EventsPage.jsx           # Search input, category filters, card list
        └── RegistrationsPage.jsx    # Table of current bookings with cancel option
```

---

