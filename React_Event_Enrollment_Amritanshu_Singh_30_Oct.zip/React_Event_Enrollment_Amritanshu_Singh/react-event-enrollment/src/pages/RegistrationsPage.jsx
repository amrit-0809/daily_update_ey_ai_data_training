import React from 'react';
import { Link } from 'react-router-dom';
import { useRegistrations } from '../context/RegistrationContext';

export const RegistrationsPage = () => {
  const { registrations, cancelRegistration } = useRegistrations();

  return (
    <main className="container">
      <div className="page-header">
        <h2>Active Registrations</h2>
        <p>View your confirmed workshop seats or cancel if your schedule changes.</p>
      </div>

      {registrations.length === 0 ? (
        <div className="empty-state">
          <h3>No registrations yet</h3>
          <p>You haven't signed up for any events yet.</p>
          <Link to="/" className="btn btn-primary">
            Browse Events
          </Link>
        </div>
      ) : (
        <div className="registrations-table-container">
          <table className="registrations-table">
            <thead>
              <tr>
                <th>Attendee Name</th>
                <th>Email Address</th>
                <th>Event Title</th>
                <th>Event Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {registrations.map((reg) => (
                <tr key={reg.id}>
                  <td className="font-semibold">{reg.fullName}</td>
                  <td>{reg.email}</td>
                  <td>{reg.eventTitle}</td>
                  <td>{reg.eventDate}</td>
                  <td>
                    <button
                      className="btn btn-danger-sm"
                      onClick={() => cancelRegistration(reg.id)}
                    >
                      Cancel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
};