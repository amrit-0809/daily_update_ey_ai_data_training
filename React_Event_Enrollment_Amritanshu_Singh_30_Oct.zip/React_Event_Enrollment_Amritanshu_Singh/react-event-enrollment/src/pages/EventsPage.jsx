import React, { useState, useMemo } from 'react';
import { useRegistrations } from '../context/RegistrationContext';
import { EventCard } from '../components/EventCard';
import { RegistrationModal } from '../components/RegistrationModal';

export const EventsPage = () => {
  const { events, getAvailableSeats } = useRegistrations();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [activeModalEvent, setActiveModalEvent] = useState(null);

  const categories = ['All', 'Technology', 'Arts', 'Life Skills'];

  // Filter events based on title search and category
  const filteredEvents = useMemo(() => {
    return events.filter((ev) => {
      const matchesSearch = ev.title
        .toLowerCase()
        .includes(searchTerm.trim().toLowerCase());
      const matchesCategory =
        selectedCategory === 'All' || ev.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [events, searchTerm, selectedCategory]);

  return (
    <main className="container">
      <div className="page-header">
        <h2>Upcoming Workshops & Events</h2>
        <p>Explore community courses, build your skill set, and enroll for free.</p>
      </div>

      <div className="filter-bar">
        <div className="search-box">
          <input
            type="text"
            placeholder="Search by event title..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            aria-label="Search events"
          />
          {searchTerm && (
            <button className="clear-btn" onClick={() => setSearchTerm('')}>
              ✕
            </button>
          )}
        </div>

        <div className="category-filters">
          {categories.map((cat) => (
            <button
              key={cat}
              className={`filter-btn ${selectedCategory === cat ? 'active' : ''}`}
              onClick={() => setSelectedCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {filteredEvents.length === 0 ? (
        <div className="empty-state">
          <h3>No events found</h3>
          <p>
            No events match your search "{searchTerm}" in category "{selectedCategory}".
          </p>
          <button
            className="btn btn-secondary"
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('All');
            }}
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="events-grid">
          {filteredEvents.map((event) => (
            <EventCard
              key={event.id}
              event={event}
              availableSeats={getAvailableSeats(event.id)}
              onSelectEvent={setActiveModalEvent}
            />
          ))}
        </div>
      )}

      {activeModalEvent && (
        <RegistrationModal
          event={activeModalEvent}
          onClose={() => setActiveModalEvent(null)}
        />
      )}
    </main>
  );
};