import React from 'react';

export const EventCard = ({ event, availableSeats, onSelectEvent }) => {
  const isSoldOut = availableSeats === 0;

  return (
    <div className={`event-card ${isSoldOut ? 'sold-out' : ''}`}>
      <div className="card-header">
        <span className={`tag tag-${event.category.toLowerCase().replace(/\s+/g, '-')}`}>
          {event.category}
        </span>
        <span className={`seats-badge ${isSoldOut ? 'badge-none' : 'badge-avail'}`}>
          {isSoldOut ? 'Fully Booked' : `${availableSeats} / ${event.seats} seats available`}
        </span>
      </div>

      <h3 className="event-title">{event.title}</h3>

      <div className="event-meta">
        <p><strong>📅 Date:</strong> {event.date}</p>
        <p><strong>⏰ Time:</strong> {event.time}</p>
        <p><strong>👥 Total Capacity:</strong> {event.seats} seats</p>
      </div>

      <div className="card-action">
        <button
          className={`btn ${isSoldOut ? 'btn-disabled' : 'btn-primary'}`}
          disabled={isSoldOut}
          onClick={() => onSelectEvent(event)}
        >
          {isSoldOut ? 'Unavailable' : 'Register Now'}
        </button>
      </div>
    </div>
  );
};