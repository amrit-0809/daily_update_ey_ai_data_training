import React from 'react';
import { NavLink } from 'react-router-dom';
import { useRegistrations } from '../context/RegistrationContext';

export const Navbar = () => {
  const { registrations } = useRegistrations();

  return (
    <header className="navbar">
      <div className="nav-container">
        <NavLink to="/" className="brand-logo">
          🎓 Community Learning Hub
        </NavLink>
        <nav className="nav-links">
          <NavLink
            to="/"
            end
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
          >
            Events
          </NavLink>
          <NavLink
            to="/registrations"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
          >
            Registrations
            <span className="badge">{registrations.length}</span>
          </NavLink>
        </nav>
      </div>
    </header>
  );
};