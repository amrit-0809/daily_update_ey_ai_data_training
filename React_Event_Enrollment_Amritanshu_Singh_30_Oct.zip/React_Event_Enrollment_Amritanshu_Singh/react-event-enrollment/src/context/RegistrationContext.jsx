import React, { createContext, useContext, useState, useEffect } from 'react';
import { initialEvents } from '../data/events';

const RegistrationContext = createContext();

export const RegistrationProvider = ({ children }) => {
  // Load saved registrations from localStorage on initial render
  const [registrations, setRegistrations] = useState(() => {
    try {
      const saved = localStorage.getItem('event_registrations');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Persist registrations to localStorage whenever state changes
  useEffect(() => {
    try {
      localStorage.setItem('event_registrations', JSON.stringify(registrations));
    } catch (e) {
      console.error('Failed to save to localStorage:', e);
    }
  }, [registrations]);

  // Derived state: calculate available seats per event
  const getAvailableSeats = (eventId) => {
    const event = initialEvents.find((e) => e.id === eventId);
    if (!event) return 0;
    const activeCount = registrations.filter((r) => r.eventId === eventId).length;
    return Math.max(0, event.seats - activeCount);
  };

  // Register attendee with validation checks
  const registerAttendee = ({ eventId, fullName, email }) => {
    const trimmedName = fullName.trim();
    const normalizedEmail = email.trim().toLowerCase();

    // 1. Basic validation
    if (!trimmedName) {
      return { success: false, message: 'Full name is required.' };
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!normalizedEmail || !emailRegex.test(normalizedEmail)) {
      return { success: false, message: 'Please provide a valid email address.' };
    }

    // 2. Capacity check
    const available = getAvailableSeats(eventId);
    if (available <= 0) {
      return { success: false, message: 'Sorry, this event is fully booked.' };
    }

    // 3. Duplicate check for the same event
    const isAlreadyRegistered = registrations.some(
      (r) => r.eventId === eventId && r.email.trim().toLowerCase() === normalizedEmail
    );
    if (isAlreadyRegistered) {
      return {
        success: false,
        message: 'This email is already registered for this event.'
      };
    }

    const event = initialEvents.find((e) => e.id === eventId);
    const newRegistration = {
      id: `REG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      eventId,
      eventTitle: event.title,
      eventDate: event.date,
      fullName: trimmedName,
      email: normalizedEmail,
      registeredAt: new Date().toISOString()
    };

    setRegistrations((prev) => [...prev, newRegistration]);
    return { success: true, message: `Successfully registered for ${event.title}!` };
  };

  // Cancel an existing registration
  const cancelRegistration = (registrationId) => {
    const shouldCancel = window.confirm('Are you sure you want to cancel this registration?');
    if (!shouldCancel) return;

    setRegistrations((prev) => prev.filter((r) => r.id !== registrationId));
  };

  return (
    <RegistrationContext.Provider
      value={{
        events: initialEvents,
        registrations,
        getAvailableSeats,
        registerAttendee,
        cancelRegistration
      }}
    >
      {children}
    </RegistrationContext.Provider>
  );
};

export const useRegistrations = () => useContext(RegistrationContext);