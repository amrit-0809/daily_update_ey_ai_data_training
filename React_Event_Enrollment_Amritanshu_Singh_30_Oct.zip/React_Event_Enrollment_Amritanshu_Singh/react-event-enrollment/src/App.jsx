import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { RegistrationProvider } from './context/RegistrationContext';
import { Navbar } from './components/Navbar';
import { EventsPage } from './pages/EventsPage';
import { RegistrationsPage } from './pages/RegistrationsPage';

export default function App() {
  return (
    <RegistrationProvider>
      <BrowserRouter>
        <div className="app-shell">
          <Navbar />
          <Routes>
            <Route path="/" element={<EventsPage />} />
            <Route path="/registrations" element={<RegistrationsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </BrowserRouter>
    </RegistrationProvider>
  );
}